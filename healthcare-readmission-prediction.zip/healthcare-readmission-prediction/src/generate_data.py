"""Generate a synthetic hospital-encounter dataset for 30-day readmission prediction.

Columns mimic real-world fields (e.g. UCI "Diabetes 130-US hospitals" dataset).
Replace data/hospital_encounters.csv with real data to reuse the pipeline.
"""
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
N = 5000

age = np.clip(rng.normal(62, 16, N), 18, 95).round().astype(int)
gender = rng.choice(["Male", "Female"], N)
length_of_stay = np.clip(rng.gamma(2.0, 2.2, N), 1, 14).round().astype(int)
num_lab_procedures = np.clip(rng.normal(40, 14, N), 1, 100).round().astype(int)
num_medications = np.clip(rng.normal(14, 6, N), 1, 40).round().astype(int)
num_diagnoses = np.clip(rng.normal(6, 2, N), 1, 12).round().astype(int)
prior_admissions_1yr = np.clip(rng.poisson(1.0, N), 0, 8)
emergency_admission = rng.binomial(1, 0.45, N)
diabetes = rng.binomial(1, 0.30, N)
heart_failure = rng.binomial(1, 0.18, N)
copd = rng.binomial(1, 0.15, N)
discharge_to = rng.choice(["Home", "Skilled Nursing", "Home Health"], N, p=[0.65, 0.20, 0.15])

# Hidden risk model (ground truth used only to simulate labels)
logit = (
    -2.6
    + 0.020 * (age - 60)
    + 0.080 * length_of_stay
    + 0.030 * (num_medications - 14)
    + 0.100 * (num_diagnoses - 6)
    + 0.450 * prior_admissions_1yr
    + 0.350 * emergency_admission
    + 0.400 * diabetes
    + 0.700 * heart_failure
    + 0.500 * copd
    + 0.300 * (discharge_to == "Skilled Nursing")
    + rng.normal(0, 0.5, N)
)
p = 1 / (1 + np.exp(-logit))
readmitted_30d = rng.binomial(1, p)

df = pd.DataFrame({
    "age": age, "gender": gender, "length_of_stay": length_of_stay,
    "num_lab_procedures": num_lab_procedures, "num_medications": num_medications,
    "num_diagnoses": num_diagnoses, "prior_admissions_1yr": prior_admissions_1yr,
    "emergency_admission": emergency_admission, "diabetes": diabetes,
    "heart_failure": heart_failure, "copd": copd, "discharge_to": discharge_to,
    "readmitted_30d": readmitted_30d,
})

# Inject realistic messiness: missing values
for col in ["num_lab_procedures", "num_medications"]:
    df.loc[rng.choice(N, int(0.03 * N), replace=False), col] = np.nan

df.to_csv("data/hospital_encounters.csv", index=False)
print(f"Saved {len(df)} rows | readmission rate: {df.readmitted_30d.mean():.1%}")

"""Train and evaluate 30-day readmission models."""
import json
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             roc_auc_score, roc_curve, confusion_matrix,
                             ConfusionMatrixDisplay)

TARGET = "readmitted_30d"
df = pd.read_csv("data/hospital_encounters.csv")

# --- 1. EDA summary ---
print("Shape:", df.shape)
print("Missing values:\n", df.isna().sum()[df.isna().sum() > 0])
print(f"Readmission rate: {df[TARGET].mean():.1%}")

X, y = df.drop(columns=TARGET), df[TARGET]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42)

# --- 2. Preprocessing ---
cat_cols = X.select_dtypes(exclude="number").columns.tolist()
num_cols = [c for c in X.columns if c not in cat_cols]
pre = ColumnTransformer([
    ("num", Pipeline([("imp", SimpleImputer(strategy="median")),
                      ("sc", StandardScaler())]), num_cols),
    ("cat", OneHotEncoder(drop="first"), cat_cols),
])

# --- 3. Models ---
models = {
    "Logistic Regression": LogisticRegression(max_iter=1000, class_weight="balanced"),
    "Random Forest": RandomForestClassifier(n_estimators=300, max_depth=8,
                                            class_weight="balanced", random_state=42),
}

results, fitted = {}, {}
for name, clf in models.items():
    pipe = Pipeline([("pre", pre), ("clf", clf)]).fit(X_train, y_train)
    pred, proba = pipe.predict(X_test), pipe.predict_proba(X_test)[:, 1]
    results[name] = {
        "accuracy": accuracy_score(y_test, pred),
        "precision": precision_score(y_test, pred),
        "recall": recall_score(y_test, pred),
        "f1": f1_score(y_test, pred),
        "roc_auc": roc_auc_score(y_test, proba),
    }
    fitted[name] = (pipe, pred, proba)

res_df = pd.DataFrame(results).T.round(3)
print("\n=== Test-set metrics ===\n", res_df)
res_df.to_csv("outputs/metrics.csv")

# --- 4. Plots ---
plt.figure(figsize=(6, 5))
for name, (_, _, proba) in fitted.items():
    fpr, tpr, _ = roc_curve(y_test, proba)
    plt.plot(fpr, tpr, label=f"{name} (AUC={results[name]['roc_auc']:.2f})")
plt.plot([0, 1], [0, 1], "k--", label="Chance")
plt.xlabel("False Positive Rate"); plt.ylabel("True Positive Rate")
plt.title("ROC Curve - 30-Day Readmission"); plt.legend(); plt.tight_layout()
plt.savefig("outputs/roc_curve.png", dpi=150); plt.close()

best = max(results, key=lambda k: results[k]["roc_auc"])
pipe, pred, _ = fitted[best]
ConfusionMatrixDisplay(confusion_matrix(y_test, pred),
                       display_labels=["Not readmitted", "Readmitted"]).plot(cmap="Blues")
plt.title(f"Confusion Matrix - {best}"); plt.tight_layout()
plt.savefig("outputs/confusion_matrix.png", dpi=150); plt.close()

# Feature importance from Random Forest
rf_pipe = fitted["Random Forest"][0]
names = rf_pipe["pre"].get_feature_names_out()
imp = pd.Series(rf_pipe["clf"].feature_importances_, index=names).sort_values()
imp.tail(10).plot.barh(figsize=(7, 5), title="Top 10 Feature Importances (Random Forest)")
plt.tight_layout(); plt.savefig("outputs/feature_importance.png", dpi=150); plt.close()

json.dump({"best_model": best, "metrics": results}, open("outputs/summary.json", "w"), indent=2)
print(f"\nBest model by ROC-AUC: {best}")
print("Top 5 risk drivers:", list(imp.tail(5).index[::-1]))
